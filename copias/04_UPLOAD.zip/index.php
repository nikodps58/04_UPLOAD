<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicios de Fotos</title>
    <link rel="stylesheet" href="./style.css">
</head>
<body>    
    <main>
        <h1>Ejercicios </h1>
        <!-- ejercicio 1: botón que activa un texto -->
        <section>
            
            <div class="div_botones">
                <div class="boton" id="boton01">
                     <p>Subir Imagenes</p>
                </div>
                <div class="boton" id="boton02">
                    <p>Descargar Imagenes</p>
                </div>
            </div>
            
        </section>
    </main>
</body>
</html>

