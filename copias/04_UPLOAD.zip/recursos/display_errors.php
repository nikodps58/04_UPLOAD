<?php
/* cuando se sube a producion el error hay que ponerlo a 0 */
    ini_set('display_errors',1);
?>    