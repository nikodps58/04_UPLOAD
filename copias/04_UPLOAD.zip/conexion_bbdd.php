<?php
    /* require_once "./php/recursos/display_errors.php"; */
    include "display_errors.php";
    
    $con=mysqli_connect("localhost","niko_dbo","Areafor@01","niko_db"); 
?>